  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>

		.hero {
			background-color: #E0FFFF;
			padding: 50px 23px;
			margin-bottom: 20px;
		}
		.super {
			background-color: #E6E6FA;
			padding: 50px 23px;
			margin-bottom: 20px;
		}
		.no-decoration{
			text-decoration: none;
		}
		.navbar{
			background-color: #008080;
		}
		.container-data {
			background-color: #E0FFFF;
			padding: 50px 23px;
			margin-bottom: 20px;
		}
    
		</style>
		<link rel="stylesheet" href="fontawesome/fontawesome/css/all.css" />
		<title>Hello, world!</title>
  </head>
  <body>
  	<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
  		<a class="navbar-brand" href="#"></a>
    <form class="form-inline my-2 my-lg-0 ml-auto">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
			<div class="icon ml-4">
				<h5>
				<i class="fa-solid fa-envelope mr-3" data-toggle="tolltip" tittle="surat masuk"></i>
				<i class="fa-solid fa-bell mr-3"data-toggle="tolltip" tittle="Notifikasi"></i>
			</h5>
			</div>

</nav>
        <div class="row no-gutters mt-5">
                <div class=" col-md-2 bg-dark mt-2 pr-3 pt-4">
        <ul class="nav flex-column ml-3 mb-5">
		<div class="container">
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
        <li class="nav-item">
            <a class="nav-link active text-white" href="#"><i class="fa-solid fa-gauge mr-2"></i>Dashboard</a><hr class="bg-secondary">
          </li>
          <li class="nav-item">
            <a class="nav-link  text-white" href=""><i class="fa-solid fa-house-user m-2"></i>Home</a><hr class="bg-secondary">
          </li>
          <li class="nav-item">
            <a class="nav-link  text-white" href="data.php"><i class="fa-solid fa-database m-2"></i>Data</a><hr class="bg-secondary">
          </li>
		  <li class="nav-item">
            <a class="nav-link  text-white" href="logout.php"><i class="fa-solid fa-right-from-bracket m-2"></i>Logout</a><hr class="bg-secondary">
          </li>
        </ul>
        </div>
		<div class="container shadow">
              <div class="col-md-10 p-5 pt-2">
			<h2>Selamat datang Admin</h2>
			<div class="container mt-4">
				<div class="row">
					<p>Website ini berisi data - data klinik Irga R. website dinamis ini dibuat untuk memenuhi tugas matakuliah Sistem Basis Data pada pertemuan 12.</p>
					<div class="hero">
					<h2>Pelayanan Rawat Inap</h2>
					<hr class="divider" />
						<article class="entry">
							
							<p style="margin-left: 2px;"><img src="img/klinik.jpg" alt="klinik" width="100px" style="float:left;"> Kami melayani pasien rawat inap menggunakan BPJS maupun asuransi swasta dengan proses yang mudah</p>
						</article>
					</div>
					<div class="super">
					<h2>Pelayanan Rawat Jalan</h2>
					<hr class="divider" />
						<article class="entry ">
							<img src="img/klinik1.png" alt="klinik" width="189px" style="float:right;">
							<p style="text-align:justify;"><img src="gambar1.png" alt="klinik" width="189px" style="float:right;"> Kami melayani pasien rawat jalan menggunakan BPJS maupun asuransi swasta dengan proses yang mudah</p>
						</article>
					</div>	
				</div>
			</div>
		</div>
		<div>
		<?php require "footer.php";?>
	</div>
</div>
</body>
</html>