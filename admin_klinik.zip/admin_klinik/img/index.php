
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>klinik</title>

    <!-- menyisipkan bootstrap -->
     <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">
    <header>
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1>Selamat datang </h1>
                        <h2>Admin Klinik</h2>
                    </div>
                    <div class="col-md-4">
                        <a href="pasien.php" 
                        class="btn btn-secondary">pasien</a>
                        <a href="obat.php" 
                        class="btn btn-success">obat</a>
                        <a href="resep_obat.php"
                         class="btn btn-secondary">resep obat</a>
                        <a href="berobat.php"
                         class="btn btn-success">berobat</a>
                        <a href="dokter.php" 
                        class="btn btn-secondary">dokter</a>
                        <a href="user.php" 
                        class="btn btn-success">user</a>
                    </div>
                </div>
            </div>
        </div>
    </header>


</body>
</html>