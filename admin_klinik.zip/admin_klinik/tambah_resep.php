<?php
error_reporting(E_ALL);
include_once 'koneksi.php';
if (isset($_POST['submit']))
{
 $id_resep = $_POST['id_resep'];
 $id_berobat = $_POST['id_berobat'];
 $id_obat = $_POST['id_obat'];


 $sql = 'INSERT INTO resep (id_resep, id_berobat, id_obat) ';
 $sql .= "VALUE ('{$id_resep}', '{$id_berobat}', '{$id_obat}')";
 $result = mysqli_query($con, $sql);
 header('location: resep_obat.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="css/bootstrap.min.css" />
    <script src="js/bootstrap.min.js"></script>
	<title>Tambah Resep</title>
	<style>
	.irga {
		background-color: 	#DEB887;
		border-radius: 5px;
		padding: 10px 23px;
		margin-bottom: 20px;
	}
	form div > label {
			display: inline-block;
			width: 100px;
			height: 30px;
	}
	form div > label {
			display: inline-block;
			width: 100px;
			height: 50px;
	}
	form input[type="text"], form textarea {
			border: 1px solid;
	}
	
	.main{
		height: 100vh;
	}
	
	.tambah-box{
		width: 900px;
		height: 600px;
		box-sizing: border-box;
		border-radius: 10px
	}
	</style>
</head>
<div class="main d-flex flex-column justify-content-center align-items-center">
		<div class="tambah-box p-5 shadow">
		<header class="irga">
		<h2 align="center" class="text-white">Tambah Resep Obat</h2>
		</header>
		<hr>
		<div class="main">
				<form method="post" action="tambah_resep.php" enctype="multipart/form-data">
				
									<hr>
									
									<table cellpadding="8">
										<tr>
										<td><b>pasien</b></td>
										<td>
										<select name="pasien" id="pasien" style="width: 200px;">
											<option value="">Pilih</option>
					

											<?php
											require "koneksi.php";
	
											$querypasien = mysqli_query($con, "SELECT * FROM pasien");
											while($data = $sql->fetch()){ // Ambil semua data dari hasil eksekusi $sql
												echo "<option value='".$data['id']."'>".$data['nama']."</option>";
											}
											?>
											</select>
										</td>
										</tr>
										<tr>
										<td><b>Kota</b></td>
										<td>
											<select name="pasien" id="kota" style="width: 200px;">
											<option value="">Pilih</option>
											</select>
											<div id="loading" style="margin-top: 15px;">
											<img src="images/loading.gif" width="18"> <small>Loading...</small>
											</div>
										</td>
										</tr>
									</table>
							
						<div class="submit">
						<input class="btn btn-primary mt-2" type="submit" name="submit" value="Simpan Data" />
						<a href="resep_obat.php" role="button"button type="button" class="btn btn-primary  mt-2">Batal</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>